"""Lexical evidence per pair: example numbers and word 4-grams the material
shares with this book's read text but with no other book read in the turn."""

import json
import re
import sys
from collections import Counter, defaultdict

pairs = json.load(open(sys.argv[1], encoding="utf-8"))
WORD = re.compile(r"[a-z0-9][a-z0-9.\-/]*")
NUM = re.compile(r"(?<![\w.])(\d+\.\d+|\d{2,}(?:,\d{3})*)(?![\w])")


def body(text):
    # drop the excerpt head lines (title, roles, teaches, scope) of read results
    return "\n".join(l for l in text.splitlines() if not re.match(r"^(\[exc_|roles:|teaches:|scope:)", l))


def grams(text, n=4):
    w = WORD.findall(text.lower())
    return {" ".join(w[i:i + n]) for i in range(len(w) - n + 1)}


by_mat = defaultdict(list)
for p in pairs:
    by_mat[(p["arm"], p["material"])].append(p)
for group in by_mat.values():
    texts = {p["book"]: body("\n".join(p["book_texts"])) for p in group}
    g = {b: grams(t) for b, t in texts.items()}
    nums = {b: set(NUM.findall(t)) for b, t in texts.items()}
    mat = group[0]["material_text"]
    mg, mn = grams(mat), set(NUM.findall(mat))
    for p in group:
        b = p["book"]
        others_g = set().union(*(g[o] for o in g if o != b)) if len(g) > 1 else set()
        others_n = set().union(*(nums[o] for o in nums if o != b)) if len(nums) > 1 else set()
        p["shared_grams"] = len((g[b] - others_g) & mg)
        p["shared_nums"] = sorted((nums[b] - others_n) & mn)[:12]
        p["book_chars"] = len(texts[b])
json.dump(pairs, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False)


def bucket(p):
    s = p["shared_grams"]
    return "0" if s == 0 else "1-4" if s < 5 else "5-19" if s < 20 else "20+"


c = Counter((p["arm"][8:], "credited" if p["credited"] else "not", bucket(p)) for p in pairs)
for k in sorted(c):
    print(k, c[k])
