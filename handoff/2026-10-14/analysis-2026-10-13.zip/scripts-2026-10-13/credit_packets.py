"""Judging packets: one markdown file per material with the material and the
book texts to judge, split into N batches of similar size."""

import json
import random
import sys
from collections import defaultdict
from pathlib import Path

pairs = json.load(open(sys.argv[1], encoding="utf-8"))
out = Path(sys.argv[2])
n_batches = int(sys.argv[3])
random.seed(7)


def pick(p):
    auto = p["arm"] == "measure-noledger"
    s = p["shared_grams"]
    if auto and p["credited"] and s < 20:
        return "auto-credited"
    if not auto and not p["credited"] and s >= 1:
        return "named-uncredited"
    if not auto and p["credited"] and s < 5:
        return "named-credited-weak"
    return None


chosen = [p for p in pairs if pick(p)]
# spot checks of the buckets counted without a judge
strong_auto = [p for p in pairs if p["arm"] == "measure-noledger" and p["credited"] and p["shared_grams"] >= 20]
zero_named = [p for p in pairs if p["arm"] != "measure-noledger" and not p["credited"] and p["shared_grams"] == 0]
spot = random.sample(strong_auto, 15) + random.sample(zero_named, 15)
for p in chosen:
    p["why"] = pick(p)
for p in spot:
    p["why"] = "spot-strong-auto" if p["credited"] else "spot-zero-named"
todo = chosen + spot

by_mat = defaultdict(list)
for p in todo:
    by_mat[(p["arm"], p["request"], p["material"])].append(p)
files = []
for i, ((arm, req, mid), group) in enumerate(sorted(by_mat.items())):
    m = group[0]
    lines = [
        f"# Packet {i:03d}",
        f"material_id: {mid}",
        f"kind: {m['kind']}",
        f"title: {m['title']}",
        "",
        "## Material text",
        "",
        m["material_text"][:30000],
        "",
    ]
    for p in group:
        lines += [
            f"## Book to judge: {p['book']}",
            "",
            f"(numbers shared with the material and no other book read: {', '.join(p['shared_nums']) or 'none'})",
            "",
            "\n\n---\n\n".join(p["book_texts"])[:16000],
            "",
        ]
    path = out / f"packet-{i:03d}.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    files.append((path.name, sum(len(x) for x in lines), [p["book"] for p in group]))
# key for scoring (kept out of the packets)
key = [{k: p[k] for k in ("arm", "request", "material", "book", "credited", "shared_grams", "why")} for p in todo]
(out / "key.json").write_text(json.dumps(key, indent=1), encoding="utf-8")
batches = [[] for _ in range(n_batches)]
sizes = [0] * n_batches
for name, size, books in sorted(files, key=lambda f: -f[1]):
    j = sizes.index(min(sizes))
    batches[j].append(name)
    sizes[j] += size
for j, b in enumerate(batches):
    (out / f"batch-{j}.txt").write_text("\n".join(sorted(b)), encoding="utf-8")
print("pairs", len(todo), "packets", len(files), "batch chars", sizes)
