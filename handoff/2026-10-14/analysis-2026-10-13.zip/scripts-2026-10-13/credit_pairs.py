"""Per (material, book read before its write): credited or not, with the texts a
judge needs. Arms: measure-ledger (excerpt_ids named) and measure-noledger
(auto credit)."""

import glob
import json
import re
import sys
from pathlib import Path

BASE = Path("C:/WEB/capy-qtools")
RUNS = BASE / "lab/playground/local/runs"
OUT = Path(sys.argv[1])
BOOK = re.compile(r"\(book ([\w-]+)\)")
EXC = re.compile(r"^\[(exc_[\w]+)\]", re.M)


def material_text(m):
    if m.get("content"):
        return m["content"]
    parts = []
    for q in m.get("questions") or []:
        parts.append(json.dumps(q, ensure_ascii=False))
    for c in m.get("cards") or []:
        parts.append(f"{c.get('front')} :: {c.get('back')}")
    return "\n".join(parts)


pairs = []
for arm in ["measure-ledger", "measure-noledger"]:
    for f in sorted(glob.glob(str(BASE / "bench/rag/reports/local/2026-10-13-noledger" / arm / "*.json"))):
        req = Path(f).stem
        d = json.load(open(f, encoding="utf-8"))
        earlier = []  # reads of earlier turns, retained or re-readable
        for ti, t in enumerate(d["turns"]):
            run = json.load(open(RUNS / t["run_id"] / "run.json", encoding="utf-8"))
            calls = run["calls"]
            reads = [(-1, b, e, x) for _, b, e, x in earlier]
            for c in calls:
                text = c.get("text_sent_to_model") or ""
                if c["name"] == "read_knowledge" and c["outcome"] == "succeeded":
                    blocks = [text]
                elif "had not been read" in text:
                    blocks = ["[exc_" + b for b in text.split("\n\n[exc_")[1:]]
                else:
                    continue
                for block in blocks:
                    m = BOOK.search(block)
                    if m:
                        reads.append((c["sequence"], m.group(1), EXC.findall(block), block))
            earlier = reads
            for mat in run["materials"]:
                # the first call whose result names the material
                seq = next(
                    (c["sequence"] for c in calls
                     if c["outcome"] == "succeeded" and mat["id"] in (c.get("text_sent_to_model") or "")),
                    None,
                )
                if seq is None:
                    continue
                credited = {b["id"] for b in (mat.get("provenance") or {}).get("books", [])}
                before = [r for r in reads if r[0] < seq]
                books = {}
                for s, book, exc, text in before:
                    books.setdefault(book, []).append(text)
                for book in sorted(set(books) | credited):
                    pairs.append({
                        "arm": arm, "request": req, "turn": ti, "material": mat["id"],
                        "kind": mat["kind"], "title": mat["title"], "book": book,
                        "credited": book in credited, "read_before": book in books,
                        "named": mat.get("excerpt_ids"),
                        "material_text": material_text(mat),
                        "book_texts": books.get(book, []),
                    })
OUT.write_text(json.dumps(pairs, ensure_ascii=False), encoding="utf-8")
from collections import Counter
c = Counter((p["arm"], p["credited"], p["read_before"]) for p in pairs)
for k, v in sorted(c.items()):
    print(k, v)
print("materials:", len({(p["arm"], p["material"]) for p in pairs}))
