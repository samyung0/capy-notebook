"""Pairs from the older playground runs in the main checkout (excerpt_ids
named by the model), one run at a time; earlier turns' reads are unknown, so
only books read in the run itself are candidates."""

import glob
import json
import re
import sys
from pathlib import Path

RUNS = Path("C:/WEB/capy-notebook/lab/playground/local/runs")
BOOK = re.compile(r"\(book ([\w-]+)\)")
EXC = re.compile(r"^\[(exc_[\w]+)\]", re.M)
pairs = json.load(open(sys.argv[1], encoding="utf-8"))
pairs = [p for p in pairs if p["arm"] != "older-named"]


def material_text(m):
    if m.get("content"):
        return m["content"]
    parts = [json.dumps(q, ensure_ascii=False) for q in m.get("questions") or []]
    parts += [f"{c.get('front')} :: {c.get('back')}" for c in m.get("cards") or []]
    return "\n".join(parts)


for path in sorted(glob.glob(str(RUNS / "*/run.json"))):
    try:
        run = json.load(open(path, encoding="utf-8"))
    except Exception:
        continue
    if not run.get("library") or not run.get("materials"):
        continue
    calls = run.get("calls", [])
    reads = []
    for c in calls:
        text = c.get("text_sent_to_model") or ""
        ok = c.get("outcome", "succeeded" if not c.get("error") else "failed") == "succeeded"
        if c.get("name") == "read_knowledge" and ok:
            blocks = [text]
        elif "had not been read" in text:
            blocks = ["[exc_" + b for b in text.split("\n\n[exc_")[1:]]
        else:
            continue
        for block in blocks:
            m = BOOK.search(block)
            if m:
                reads.append((c.get("sequence", 0), m.group(1), block))
    for mat in run["materials"]:
        seq = next(
            (c.get("sequence", 0) for c in calls
             if mat["id"] in (c.get("text_sent_to_model") or "") and not c.get("error")),
            None,
        )
        if seq is None:
            continue
        credited = {b["id"] for b in (mat.get("provenance") or {}).get("books", [])}
        books = {}
        for s, book, text in reads:
            if s < seq:
                books.setdefault(book, []).append(text)
        for book in sorted(books):
            pairs.append({
                "arm": "older-named", "request": Path(path).parent.name, "turn": 0,
                "material": mat["id"], "kind": mat["kind"], "title": mat["title"],
                "book": book, "credited": book in credited, "read_before": True,
                "named": mat.get("excerpt_ids"), "material_text": material_text(mat),
                "book_texts": books[book],
            })
json.dump(pairs, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False)
older = [p for p in pairs if p["arm"] == "older-named"]
print("older pairs", len(older), "credited", sum(p["credited"] for p in older),
      "materials", len({p["material"] for p in older}))
