import glob
import json
from collections import Counter, defaultdict

D = "C:/Users/yungc/AppData/Local/Temp/claude/C--WEB-capy-notebook/f1dc38b9-6761-46ef-a735-cc0a98d56c02/scratchpad/"
pairs = json.load(open(D + "pairs.json", encoding="utf-8"))
key = json.load(open(D + "credit-judge/key.json", encoding="utf-8"))
verdicts = {}
for f in glob.glob(D + "credit-judge/verdicts-*.jsonl"):
    for line in open(f, encoding="utf-8"):
        if line.strip():
            v = json.loads(line)
            verdicts[(v["material_id"], v["book"])] = v
print("verdicts", len(verdicts), "key", len(key))
missing = [k for k in key if (k["material"], k["book"]) not in verdicts]
print("unjudged", len(missing))

why = {(k["material"], k["book"], k["arm"]): k["why"] for k in key}
rows = defaultdict(Counter)
for p in pairs:
    arm = "auto" if p["arm"] == "measure-noledger" else "named"
    k = (p["material"], p["book"])
    v = verdicts.get(k)
    s = p["shared_grams"]
    if v and why.get((p["material"], p["book"], p["arm"])):
        label = v["label"]
        src = "judged"
    else:
        # unjudged buckets: strong overlap counts as used, none as not used
        label = "used" if s >= (20 if arm == "auto" else 5) else "unrelated"
        src = "lexical"
    rows[(arm, "credited" if p["credited"] else "uncredited")][label] += 1
    rows[(arm, "credited" if p["credited"] else "uncredited", src)][label] += 1
for k in sorted(rows):
    c = rows[k]
    n = sum(c.values())
    print(k, n, dict(c), f"used {100 * c['used'] / n:.0f}%")

# spot checks
print("-- spot checks")
for k in key:
    if k["why"].startswith("spot"):
        v = verdicts.get((k["material"], k["book"]))
        print(k["why"], k["shared_grams"], v["label"] if v else "?")

# lexical score vs judged label, auto credited
print("-- auto credited judged, label by overlap bucket")
b = defaultdict(Counter)
for k in key:
    v = verdicts.get((k["material"], k["book"]))
    if not v:
        continue
    s = k["shared_grams"]
    bucket = "0" if s == 0 else "1-4" if s < 5 else "5-19" if s < 20 else "20+"
    b[(k["why"], bucket)][v["label"]] += 1
for kk in sorted(b):
    print(kk, dict(b[kk]))

# per material: books credited vs used (auto)
print("-- auto materials: credited books, used books")
mats = defaultdict(lambda: [0, 0])
for p in pairs:
    if p["arm"] != "measure-noledger" or not p["credited"]:
        continue
    v = verdicts.get((p["material"], p["book"]))
    label = v["label"] if v and why.get((p["material"], p["book"], p["arm"])) else ("used" if p["shared_grams"] >= 20 else "unrelated")
    mats[p["material"]][0] += 1
    mats[p["material"]][1] += label == "used"
dist = Counter((c, u) for c, u in mats.values())
print("materials", len(mats), "all credited used:", sum(1 for c, u in mats.values() if c == u),
      "some over-credit:", sum(1 for c, u in mats.values() if u < c),
      "none used:", sum(1 for c, u in mats.values() if u == 0))
