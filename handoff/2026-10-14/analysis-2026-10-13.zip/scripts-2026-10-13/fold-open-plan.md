# Fold open questions into add_questions (Epo approved, 2026-10-14)

Worktree `C:/WEB/capy-lenient`: create branch `fold-open-questions` from the latest `origin/main`
(`git fetch` first; the worktree's current branch `agent-leniency` is already merged). `.env.local` is
there (git-ignored, never commit).

## Why

`add_open_question` was refused on 15 of 41 calls in the playground runs; 9 had scrambled arguments
(the quiz id in `model_answer` or `explanation`, `question` missing, one key reading
`model_answer: null</arg_value><arg_key>question`). GLM fills tool arguments in alphabetical order
whatever order our schema sends (probed 2026-10-14), so `question` and `quiz_id` come last, after
three long top-level text fields, and that tail is what gets lost. `add_questions`, whose questions
are JSON objects inside one `questions` array, had no scrambling in 149 calls. Folding open questions
into `add_questions` also removes one tool (~400 tokens on every model call) and gives the agent one
question shape everywhere: a note's ```quiz fence already takes exactly this union.

## Change (agent contract v25; Go and pipeline deploy together)

1. **Go `server/internal/agenttools/agenttools.go`**
   - Remove the `add_open_question` tool.
   - `add_questions` items take a third kind, an open question: `question`, `marks` (1 to
     `fieldlimits.QuestionMarks`), `markscheme` (1 to 5 `{text, marks}` adding up to marks),
     `model_answer` (max `fieldlimits.QuizOpenAnswer`), optional `hints`, optional `explanation`.
     The item's fields decide its kind: `options`+`correct` multiple choice, `accepted` (+`unit`)
     short answer, `marks`+`markscheme`+`model_answer` open. Multiple-choice and short-answer stay
     1 mark each.
   - Give the item's `question` a description ("The question as the learner reads it." or similar).
   - Rewrite the `add_questions` description briefly to name the three kinds, keeping one compact
     example (add one open item to the existing example rather than a second example). Keep the
     schema lean: the model reads it on every call.
   - The note format text (`noteMarkdownDescription`, the ```quiz fence sentence) says each item is
     "a question as add_questions takes it" (no separate open-question wording).
   - Bump `ContractVersion` to 25 with a version note; update `agenttools_test.go`.
   - `server/internal/embeds/embeds.go:352` lists `add_open_question` among a kind's agent tools
     (the embed catalog, owned by the "Embed standardization strategy" session): drop it there, and
     regenerate. Touch nothing else in `embeds/`.
   - `pnpm gen:openapi` regenerates `pipeline/pipeline/generated/agent_tools.json`,
     `pipeline/pipeline/generated/embeds.json` and `src/api/embeds.generated.ts`.
2. **Pipeline**
   - `contract.py` `SUPPORTED_VERSION = 25`; `HANDLER_CHECKED` loses `add_open_question`.
   - `questions.py`: `add_questions` items accept the open kind (today only fence items do); the
     open-item schema now comes from the `add_questions` item schema instead of
     `_schema("add_open_question")`; remove the `add_open_question` branches and wording ("rewrite
     one with add_open_question", "marked on one is add_open_question", etc. become add_questions /
     open-item wording). Partial success, blank-dropping (per kind's required fields), unit
     stripping, `replaces`, `_target_problems` (chapter_id ignored with quiz_id; quiz_id+title
     refused) all apply as today. A quiz can start with only open items (title).
   - `tools.py`: remove `_add_open_question` and its registration; `write_questions` serves
     add_questions only.
   - `agent.py` (lines ~66, ~121) and `skills.py` `REQUIRES`: drop the tool.
   - Building skill (`prompts/skills.py`, the "Quizzes:" line): add_questions writes multiple-choice,
     short-answer and open (written-answer, with a markscheme) questions, creating the quiz with its
     first ones (title) or adding to a quiz by quiz_id, a note's quiz too. Keep it one sentence.
3. **Playground and bench**: `lab/playground/scripts/playground.py` (stubs, tool lists),
   `lab/playground/README.md`, `bench/rag/intake/scripts/run_requests.py` WRITES list.
4. **Tests**: update `pipeline/tests/test_questions.py`, tool/agent tests and Go tests; add focused
   cases: add_questions with mixed kinds (mcq + short + open) in one call, an all-open new quiz by
   title, an open item with a wrong markscheme sum (refused per item, others saved), an open item
   carrying `options` (refused with the kind's shape). No tests for the removed tool's absence.
   Run `pnpm test:go ./internal/agenttools/...` (Docker may be down; then `go test` for DB-free
   packages), the pipeline tests touched (`uv run --extra test pytest -q <files>`), `pnpm fmt:go`,
   `pnpm fmt:py`, and the playground self-check (`--check`).
5. **Docs**: `openwiki/agentic-retrieval.md` (tool table row, the question-tools text),
   `openwiki/test-catalog.md`, and a dated decision line in `human/agentic-retrieval.md`
   (2026-10-14, Epo: open questions fold into add_questions; reason above; supersedes the separate
   open-question tool in the 2026-10-13 line, which should be edited so the two don't conflict).

## Rules

Read AGENTS.md and the `human` skill first. Don't edit `collaboration-rs/` or `collaboration/`.
Commit on `fold-open-questions` (message ends with
`Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`), rebase onto the latest `origin/main`
before finishing, do not push, never skip hooks. Kill any process you start. Final reply: a short
summary, test results, anything you could not do.
