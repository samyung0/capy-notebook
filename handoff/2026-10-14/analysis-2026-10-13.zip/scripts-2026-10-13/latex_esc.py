"""Accepted quiz/flashcards fences whose double-quoted strings hold a LaTeX
command that YAML reads as an escape (\neq -> newline + 'eq')."""

import glob
import json
import re

base = "C:/WEB/capy-qtools/"
FENCE = re.compile(r"^```(quiz|flashcards)[^\n]*\n(.*?)^```", re.M | re.S)
DQ = re.compile(r'"((?:[^"\\]|\\.)*)"')
# A backslash not preceded by another, then a YAML escape letter starting a word.
LATEX_ESC = re.compile(r"(?:^|[^\\])\\(n|t|r|b|f|a|v|e|N|L|P|x|u|U)[a-zA-Z]")
scope_args = []
ok = bad = 0
examples = []
runs = sorted(glob.glob(base + "lab/playground/local/runs/*/run.json"))
for p in runs:
    run = json.load(open(p, encoding="utf-8"))
    for c in run["calls"]:
        a = c.get("args") if isinstance(c.get("args"), dict) else {}
        if c["name"] == "create_material" and "scope" in a and not isinstance(a["scope"], dict):
            scope_args.append(repr(a["scope"])[:120])
        if c["name"] not in ("create_material", "edit_document") or c["outcome"] != "succeeded":
            continue
        texts = [a.get("content") or ""] + [
            cmd.get("text") or cmd.get("markdown") or ""
            for cmd in a.get("commands", [])
            if isinstance(cmd, dict)
        ]
        for t in texts:
            for m in FENCE.finditer(t):
                hits = [s for s in DQ.findall(m.group(2)) if LATEX_ESC.search(s)]
                if hits:
                    bad += 1
                    if len(examples) < 8:
                        examples.append((p.replace("\\", "/").split("/runs/")[1][:22], m.group(1), hits[0][:110]))
                else:
                    ok += 1
print("runs scanned", len(runs))
print("accepted fences with a LaTeX command read as a YAML escape:", bad, "of", ok + bad)
for e in examples:
    print(" ", e)
print("non-object scope args:", scope_args[:5])
