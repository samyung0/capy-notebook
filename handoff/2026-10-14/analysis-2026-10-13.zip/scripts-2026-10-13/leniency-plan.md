# Agent write leniency (approved by Epo, 2026-10-13)

Worktree: `C:/WEB/capy-lenient`, branch `agent-leniency`, from origin/main 614c76b7.
`.env.local` is copied in (git-ignored; never commit it).

## Why

In the 2026-10-13 ledger/no-ledger runs (report `bench/rag/reports/2026-10-13-ledger-vs-noledger.md`),
45 refused writes had nothing to do with the ledger: 32 note/edit writes and 13 question-tool calls.
Rule agreed with Epo: repair a payload only where it can mean one thing, say in the success
result what was repaired when it was a format repair (one short line, so the model stops repeating
the slip), and keep refusing everything else with today's precise messages. Leniency is for agent
writes only and lives in the pipeline: the editor, paste and the collaboration server's converter
stay strict. No agent contract change (no version bump): the schemas the model sees do not change.

Rejected payloads to test against are quoted below; real examples of each are in the 2026-10-13
run records if you need more (`C:/WEB/capy-qtools/lab/playground/local/runs/*/run.json`, read-only).

## Coordination

Another session ("embeds") owns the embed catalog work in `todo-embeds.md`: Python kind lists and
validators (`questions.py` `_MEDIA`, `_chart_problems`), the agent-facing text (`agenttools.go`
`Formats.note`, skills) and a contract rename/version bump. Do not restructure those lists, do not
add a new hand-written list of block kinds (read fence names and chart kinds from what already
exists, e.g. `contract.MEDIA_BLOCKS` enums), and do not touch agent-facing text or the contract.
Do not edit `collaboration-rs/` or `collaboration/` (another session owns them). Before finishing,
rebase onto the latest `origin/main` and resolve conflicts.

## Items

### 1. Blank means absent (schema-aware, every tool)

- Drop a property whose value is `null`, `""` (or whitespace only), `[]`, `{}` or the text `"null"`
  (case-insensitive) when the property is **not required** at that position. Required properties
  are kept as sent, so `replace_text` with `text: ""` still deletes text and a blank required field
  still gets today's "missing/blank" message.
- Generic tools: walk the arguments with the tool's `inputSchema` from `contract.DEFINITIONS`
  (properties/required, array `items`, and `oneOf` variants picked by their `type` const, as
  `contract._variant_problem` does) and apply it in the dispatch just before
  `contract.validate_args` (`tools.py`, the call near "Dispatch rechecks what admission offered").
  The handler must receive the cleaned arguments too.
- Question tools (HANDLER_CHECKED) and quiz fences in notes: per question item, drop blank fields
  except the item kind's required ones (`question` and `NEEDS[kind]` in `questions.py`; open:
  `marks`, `markscheme`, `model_answer`). This replaces `questions.drop_nulls` (remove it; its
  callers in `tools.py` and the playground use the new function). Unknown fields with a blank value
  are dropped too (`back: ""` on a quiz question); unknown fields with content are still refused.
- Seen: `unit: ""`, `back: ""`, `quiz_id: ""`, `quiz_id: "null"`, `accepted: []` on multiple choice,
  `target_id: null` in an edit command, `create_material` `scope: []`.
- No result note needed: nothing is lost.

### 2. Plot and chart fences in agent notes

In the pipeline's note write path (where `questions.note_fences` runs for `create_material`
and for edit commands that insert or replace note markdown), normalize each ```chart and ```plot
fence body before the markdown goes to the converter:
- body is not JSON → parse it as YAML (`yaml.safe_load`); it must be a mapping, else leave the
  fence as written so the converter's error reaches the model as today;
- `type` missing → the fence's name;
- a chart fence whose `type` is one of the chart kinds (take the enum from `contract.MEDIA_BLOCKS`)
  and has no `kind` → `kind` = that value, `type` = `chart`;
- re-emit the body as compact JSON (keep the fence's indent and backticks).
Result line when anything was repaired, e.g. "Read plot fence 2 from YAML; a plot fence is JSON."
Seen: a plot written as YAML (4 runs); `"type"` missing (2); `"type": "line"` in a chart fence (1).

### 3. Quiz and flashcards YAML, repaired only after a parse failure

Quiz fences are parsed in `questions._fence` (BaseLoader). Flashcards fences are currently parsed
only by the TS converter; give them the same pipeline pre-parse (parse, check `cards` with a
non-empty `front` and `back` each, re-emit the body as JSON, which the converter's YAML parser
accepts; keep any other card fields as sent) so the repair applies to both.
When the first parse fails, apply all three repairs and parse once more; if it still fails,
report the **original** error as today:
- a trailing comma after a closing `]` or `}` at the end of a line: `options: ["a", "b"],`;
- inside a double-quoted scalar, a backslash that is not part of `\\` and not `\"`, followed by a
  letter, is doubled (LaTeX: `"$\hat{y} = a + bx$"`, `"$\langle\cos(nt)\rangle$"`). Only on the
  failure path, so strings that already parse are never touched;
- a single-line unquoted value after a text key (`question`, `explanation`, `correct`,
  `model_answer`, `text`, `front`, `back`) or an unquoted list item under `options`/`accepted`,
  that contains `": "` or `" #"`, is wrapped in double quotes (JSON-escaped):
  `front: Binomial or normal: "how many of 40 seeds germinate?"`,
  `explanation: Short the 5 V source; the two 10 Ω resistors are then in parallel: 10 ∥ 10 = 5 Ω.`
Result line naming the fence and the repair, e.g. "Repaired quiz fence 1 (LaTeX backslashes); in
YAML double quotes write \\ for a backslash."

### 4. Unit repeated inside an accepted answer

Short answer with `unit`: an accepted answer that is a number followed by the unit (optional
space), e.g. `"5%"` with `unit: "%"`, becomes the number; then de-duplicate `accepted`. Applies to
add_questions and quiz fences. No note needed.

### 5. `chapter_id` with `quiz_id`

`add_questions` / `add_open_question` with `quiz_id` and `chapter_id`: ignore `chapter_id` and add
a result line ("chapter_id ignored: quiz <id> keeps its chapter"). `quiz_id` with `title` stays
refused (it may mean a new quiz was intended). Update `_target_problems` accordingly.

### 6. Do not offer whole-page figures

A library figure whose bbox is the whole page (`deck.WHOLE_PAGE`, `[0,0,1000,1000]`) cannot be
placed (note_figures refuses it). Leave such figures out wherever figures are offered to the model:
the excerpt/section read results' "Figures:" list and the `figures:` facet ids (see `library.py`,
which already leaves out decorative and excluded figures, "which a model never picks"). Keep the
refusal in `note_figures` as the backstop. 5 refusals in the runs came from these.

### 7. Playground: quizzes from earlier turns

`lab/playground/scripts/playground.py` question-tool stubs refuse a quiz made in an earlier turn of
the same conversation ("quiz_id: … is not a quiz this run made"), which production accepts. Make the
stub find materials (at least quizzes) written by earlier turns of the conversation, using whatever
the playground already keeps per conversation (history / earlier run records). Keep it small.
Also make sure the playground's write stubs go through the same pipeline normalization (items 1-3),
so the playground and production agree; the playground's `check_note` converter stand-in should see
the normalized markdown.

### 8. Narrower automatic credit (approved by Epo, 2026-10-13, added after the start)

Production code (`pipeline/pipeline/retrieval/tools.py` `write_sources` / `LibraryReads`), which the
playground also runs. Today a write naming no `excerpt_ids` is credited with every excerpt read
since the last write (or all of this turn's reads when none are new). Measured on the 2026-10-13
runs: only 68% of those book credits were actually used, while excerpts GLM names itself are 95%
used and it forgets a used book 0.7% of the time. Keep named credits exactly as today. Change only
the fallback:
- candidates: the same excerpts as today (`uncredited()`), grouped by book;
- the write's text: every string the write sends (for example walk the arguments' string leaves:
  note markdown, edit command text, question fields, slide SVG text), lower-cased;
- a candidate book is credited when its read text this turn (the text the model was shown, e.g.
  what `library_evidence` keeps for the read) shares with the write's text at least one word
  4-gram, or one number with a decimal point or at least two digits, that appears in no other
  candidate book's read text. Strip the excerpt head lines (`[exc_…]` title line, `roles:`,
  `teaches:`, `scope:`) before comparing; tokenize words as `[a-z0-9][a-z0-9.\-/]*`;
- if no candidate passes, the write credits no library excerpt (figure excerpts placed in the note
  are still credited as today); say so in the result line? No: keep results unchanged;
- only the credited excerpts count as credited/retained (`landed`), so the narrowing also narrows
  what later turns carry. `credit()` after a landed write still marks every read as credited, as now.
On the measured runs this keeps 86% precision (up from 68%), drops 2 of 129 used books, and leaves no
material uncredited. Unit tests with two books, one of whose example numbers appear in the write.
Document the rule in `openwiki/agentic-retrieval.md` (where automatic crediting is described) and
the decision line in `human/agentic-retrieval.md`.

## Tests and docs

- Focused pytest cases per item (the payloads above are good fixtures), in the existing test files
  (`pipeline/tests/test_questions.py`, tool/contract tests). No smoke tests. Run
  `pnpm test:pipeline:offline` (or the narrower files) and `pnpm fmt:py`; run the playground
  self-check (`python lab/playground/scripts/playground.py --check`, see its README) if it exists.
- Update `openwiki/test-catalog.md` rows, a short paragraph in `openwiki/agentic-retrieval.md`
  (agent write leniency: what is repaired, that it is agent-only and in the pipeline), and a dated
  decision line in `human/agentic-retrieval.md` (2026-10-13, Epo approved this set; quiz_id+title
  still refused).
- Commit on `agent-leniency` (end the message with
  `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`), do not push. Never skip hooks.
- Kill any process you start before finishing. Final reply: a short summary (what changed, test
  results, anything you could not do), not diffs.
