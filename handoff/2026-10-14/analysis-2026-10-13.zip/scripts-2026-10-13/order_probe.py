"""Does GLM (through Relace) fill tool arguments in our schema's property order,
or alphabetically? Prints the key order of each returned call."""

import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path("lab/playground/scripts").resolve()))
from common import prepare_environment  # noqa: E402

print("env...", flush=True); prepare_environment("lab"); print("env ok", flush=True)

from pipeline import registry  # noqa: E402
from pipeline.elitellm import client  # noqa: E402

ORDER = ["quiz_id", "question", "marks", "markscheme", "model_answer", "explanation", "hints"]
PROPS = {
    "quiz_id": {"type": "string", "description": "The quiz to add to."},
    "question": {"type": "string", "description": "The question as the learner reads it."},
    "marks": {"type": "integer", "minimum": 1, "maximum": 20},
    "markscheme": {
        "type": "array",
        "items": {"type": "object", "properties": {"text": {"type": "string"}, "marks": {"type": "integer"}}, "required": ["text", "marks"]},
    },
    "model_answer": {"type": "string", "description": "A full-marks answer."},
    "explanation": {"type": "string", "description": "Optional: the worked solution."},
    "hints": {"type": "array", "items": {"type": "string"}, "description": "Optional nudges."},
}


def tool(order):
    return {
        "type": "function",
        "function": {
            "name": "add_open_question",
            "description": "Add one open question with a markscheme to a quiz.",
            "parameters": {
                "type": "object",
                "properties": {k: PROPS[k] for k in order},
                "required": ["quiz_id", "question", "marks", "markscheme", "model_answer"],
            },
        },
    }


async def main(n):
    spec = registry.ModelConfig(
        version=1,
        provider_name="zai",
        model_name="glm-5.3-flash",
        provider_slug="zai",
        model_slug="glm-5.3-flash",
        platform_enabled=True,
        params={"temperature": 0.3},
        slots=(registry.Slot.CHAT,),
        thinking_levels=("low", "mid", "high", "max"),
        default_thinking="high",
        context_window_tokens=200000,
    )
    messages = [
        {"role": "system", "content": "You write study quizzes. Use the tool."},
        {"role": "user", "content": "Add one 3-mark open question to quiz mat_1 asking why a red blood cell bursts in pure water, with two hints and an explanation."},
    ]
    for label, order in (("custom", ORDER), ("alphabetical", sorted(ORDER))):
        for i in range(n):
            raw = await client.complete(spec, messages, tools=[tool(order)], reasoning=False, max_tokens=1500)
            calls = raw.choices[0].message.tool_calls or []
            for c in calls:
                args = json.loads(c.function.arguments)
                print(label, i, list(args))


asyncio.run(main(int(sys.argv[1]) if len(sys.argv) > 1 else 3))
