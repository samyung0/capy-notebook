import json, glob, sys, collections
for arm in sys.argv[1:]:
    c = collections.Counter(); r = collections.Counter(); errs = collections.Counter()
    for f in glob.glob(arm + "/*.json"):
        d = json.load(open(f, encoding="utf-8"))
        for t in d["turns"]:
            for w in t["writes"]:
                c[w["name"]] += 1
                if w["outcome"] != "succeeded":
                    r[w["name"]] += 1
                    errs[(w["name"], (w["error"] or "")[:90])] += 1
    print("==", arm)
    for n in sorted(c):
        print(f"  {n:22s} {r[n]:3d}/{c[n]:3d}  {100*r[n]/c[n]:.0f}%")
    tot = sum(c.values()); rt = sum(r.values())
    print(f"  {'TOTAL':22s} {rt:3d}/{tot:3d}  {100*rt/tot:.0f}%")
